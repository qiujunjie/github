package com.cmcc.ishang.lib.step;

public class DataStructPerDay
{
	public boolean isSend=false;
	public int year=0;
    public int month=0;
    public int day=0;
    public int step_all=0;
    public int step_ef_all=0;
	public int calorie=0;
	public int distance=0;
	public int sedentary=0;
	public int lightly=0;
	public int fairly=0;
	public int very=0; 
	
	public void  clear()
	{
		
		isSend=false;
		year=0;
	    month=0;
	    day=0;
	    step_all=0;
	   step_ef_all=0;
		calorie=0;
		distance=0;
		sedentary=0;
		lightly=0;
		fairly=0;
		very=0; 
	}


}
