package com.cmcc.ishang.lib.step;

public class StrParaTable {
	//str_device_status
	public static int device_status;
	public static int wearing_status;
	public static int power_status;	
	public static int connect_status;	
	public static int[] connected_id;
	//str_user_para
	public static int  gender=1; 
	public static int  age=40;
	public static int  height=170; 
	public static int  reserve=0;
	//str_product_patch
	public static int  weight=50;
	public static int  step_length=60;
	
}
