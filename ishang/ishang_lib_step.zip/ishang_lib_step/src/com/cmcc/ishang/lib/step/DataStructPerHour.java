package com.cmcc.ishang.lib.step;

public class DataStructPerHour
{
	public int year=0;
	public boolean sendflag=false;
	public int month=0;
	public int day=0;
	public int hour=0;
	public int[] step_per5min=new int[12];
	public int[] calory_per5min=new int[12];
	//uint8_t sedentary[12];
	public int []lightly=new int[12];
	public int []fairly=new int[12];
	public int []very=new int[12];
	public int []yxbssum=new int[12];
	public int distance_perHour;
	
	public void clear()
	{
		year=0;
		sendflag=false;
		month=0;
		day=0;
		hour=0;
		distance_perHour=0;
		for(int i=0;i<12;i++)
		{
			step_per5min[i]=0;
			calory_per5min[i]=0;
			lightly[i]=0;
			fairly[i]=0;
			very[i]=0;
			yxbssum[i]=0;
			
		}
		
	}
}
