package cmcc.mhealth.slidingcontrol;

import android.support.v4.app.Fragment;

public class HomeFragment extends Fragment {

}
