package cmcc.mhealth.bean;

public class GPSListBean {
	public String time;
	public GPSListInfo listInfo;
}
