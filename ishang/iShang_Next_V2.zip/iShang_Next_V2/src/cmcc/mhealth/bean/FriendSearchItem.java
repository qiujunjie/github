package cmcc.mhealth.bean;

public class FriendSearchItem {
	public String name;
	public String avatar;
	
}
