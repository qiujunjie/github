package cmcc.mhealth.bean;

public class ContectGroupData {
	public String groupname;
	public String quanpin;
	public String pinyin;
	public String groupid;
	public String getGroupid() {
		return groupid;
	}
	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getQuanpin() {
		return quanpin;
	}
	public void setQuanpin(String quanpin) {
		this.quanpin = quanpin;
	}
	public String getPinyin() {
		return pinyin;
	}
	public void setPinyin(String pinyin) {
		this.pinyin = pinyin;
	}
	
	
}
