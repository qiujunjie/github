package cmcc.mhealth.bean;

import java.util.List;

/**
 * �û��Ļ�����Ϣ
 * @author qjj
 *
 */
public class UserBaseInfo {
	public String name;//����
	public String nickname;//xx
	public String weight;//xx
	public String height;//xx
	public String gender;//xx
	public String birthday;//xx
	public String score;//xx
	public String avarta;//xx
	public String targetweight;//xx
	public String targetstep;//xx
	public List<UserCompanyInfo> clubarray;
}
