package cmcc.mhealth.bean;
/**
 * ���ڴ�����������
 * @author zy
 *
 */
public class RankUserBean {
	private String myrankid;
	private String memberseq;
	private String membername;
	private String groupname;
	private String member7avgstep;
	private String type;
	private String imageurl;
	public String getMyrankid() {
		return myrankid;
	}
	public void setMyrankid(String myrankid) {
		this.myrankid = myrankid;
	}
	public String getMemberseq() {
		return memberseq;
	}
	public void setMemberseq(String memberseq) {
		this.memberseq = memberseq;
	}
	public String getMembername() {
		return membername;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getMember7avgstep() {
		return member7avgstep;
	}
	public void setMember7avgstep(String member7avgstep) {
		this.member7avgstep = member7avgstep;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getImageurl() {
		return imageurl;
	}
	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}
	
}
