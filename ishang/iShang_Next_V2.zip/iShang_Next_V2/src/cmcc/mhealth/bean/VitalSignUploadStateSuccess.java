package cmcc.mhealth.bean;
/**
 * ������������
 * @author zy
 *
 */
public class VitalSignUploadStateSuccess {
	private String UpdateTime;

	public String getUpdateTime() {
		return UpdateTime;
	}

	public void setUpdateTime(String updateTime) {
		UpdateTime = updateTime;
	}
	
}
