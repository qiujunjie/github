package cmcc.mhealth.bean;

public class Group7Info {
	public String step;
	public String distant;
	public String calory;
	public String complianceday;
}
